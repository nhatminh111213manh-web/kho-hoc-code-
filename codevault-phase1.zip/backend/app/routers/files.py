from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models.file import FileRecord
from app.schemas.file import FileMetadataOut
from app.security.rate_limit import rate_limit
from app.storage import get_storage

router = APIRouter(prefix="/api/files", tags=["files"])


def _get_active_record(db: Session, file_id: str) -> FileRecord:
    record = db.get(FileRecord, file_id)
    # Same 404 whether the file never existed or is disabled/expired —
    # don't leak which case it is to an unauthenticated caller.
    if record is None or record.is_disabled:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")
    if record.expires_at and record.expires_at < datetime.utcnow():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")
    if record.max_downloads is not None and record.download_count >= record.max_downloads:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")
    if not record.is_public:
        # Private files are a registered-user (Phase 2) feature; for now
        # anonymous access to a private file is simply refused.
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This file is private.")
    return record


@router.get("/{file_id}", response_model=FileMetadataOut)
def get_file_metadata(file_id: str, db: Session = Depends(get_db)):
    record = _get_active_record(db, file_id)
    return FileMetadataOut(
        id=record.id,
        original_name=record.original_name,
        size=record.size,
        mime_type=record.mime_type,
        is_public=record.is_public,
        has_password=record.password_hash is not None,
        download_count=record.download_count,
        expires_at=record.expires_at,
        created_at=record.created_at,
    )


@router.get(
    "/{file_id}/download",
    dependencies=[Depends(rate_limit("download", settings.RATE_LIMIT_DOWNLOADS_PER_MINUTE))],
)
def download_file(file_id: str, db: Session = Depends(get_db), storage=Depends(get_storage)):
    record = _get_active_record(db, file_id)

    if not storage.exists(record.stored_name):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")

    record.download_count += 1
    db.add(record)
    db.commit()

    # Quote the filename defensively; original_name was already sanitized
    # at upload time but this keeps the header well-formed regardless.
    safe_name = record.original_name.replace('"', "'")
    headers = {
        "Content-Disposition": f'attachment; filename="{safe_name}"',
        "Content-Length": str(record.size),
    }
    return StreamingResponse(
        storage.open(record.stored_name),
        media_type=record.mime_type,
        headers=headers,
    )

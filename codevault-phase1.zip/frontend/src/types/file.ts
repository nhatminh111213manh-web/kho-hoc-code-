export interface UploadResponse {
  id: string;
  original_name: string;
  size: number;
  mime_type: string;
  download_url: string;
  share_url: string;
  created_at: string;
}

export interface FileMetadata {
  id: string;
  original_name: string;
  size: number;
  mime_type: string;
  is_public: boolean;
  has_password: boolean;
  download_count: number;
  expires_at: string | null;
  created_at: string;
}

export type UploadStatus = "idle" | "uploading" | "done" | "error";

export interface UploadItem {
  localId: string;
  file: File;
  progress: number; // 0-100
  status: UploadStatus;
  error?: string;
  result?: UploadResponse;
}

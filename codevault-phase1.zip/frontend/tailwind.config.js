/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0D0F14",
        surface: "#12141C",
        raised: "#171A24",
        border: "#242836",
        text: "#E7E9EE",
        muted: "#8B93A7",
        accent: "#4C6FFF",
        "accent-soft": "#1A2040",
        danger: "#F0665C",
      },
      fontFamily: {
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"],
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

import { Link } from "react-router-dom";

export function Header() {
  return (
    <header className="border-b border-border">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-2">
          <svg width="22" height="22" viewBox="0 0 32 32" fill="none">
            <rect width="32" height="32" rx="7" fill="#4C6FFF" />
            <path
              d="M11 10 L6 16 L11 22 M21 10 L26 16 L21 22"
              stroke="#0D0F14"
              strokeWidth="2.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="font-mono text-[15px] font-semibold tracking-tight">codevault</span>
        </Link>
        <nav className="flex items-center gap-3 text-sm">
          <button className="rounded-md px-3 py-1.5 text-muted transition-colors hover:text-text">
            Log in
          </button>
          <button className="rounded-md bg-accent px-3.5 py-1.5 font-medium text-white transition-opacity hover:opacity-90">
            Sign up
          </button>
        </nav>
      </div>
    </header>
  );
}

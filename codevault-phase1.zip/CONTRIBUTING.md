# Contributing to CodeVault

Thanks for considering a contribution! CodeVault is built in phases (see
the roadmap in `README.md`) — please check which phase an area belongs to
before starting large work, so effort isn't duplicated.

## Getting set up

Follow the "Development setup" section in `README.md` (Docker or
Codespaces are the fastest paths). Once running:

- Backend: `http://localhost:8000/docs` has interactive API docs (Swagger UI).
- Frontend: `http://localhost:5173`.

## Workflow

1. Open an issue first for anything non-trivial, so the approach can be
   discussed before you invest time.
2. Fork and branch from `main`: `git checkout -b feat/short-description`.
3. Keep changes focused — one logical change per pull request.
4. Follow existing patterns:
   - Backend: routers stay thin; business logic lives in `app/services/`;
     never build filesystem paths from user input directly (see
     `app/security/validation.py` and `app/storage/local.py`).
   - Frontend: components in `src/components/`, pages in `src/pages/`,
     API calls only in `src/services/`.
5. Add or update tests/manual verification steps for anything touching
   upload, download, or auth.
6. Run linters/type checks before opening a PR:
   ```bash
   cd backend && python -m py_compile $(find app -name '*.py')
   cd frontend && npx tsc --noEmit
   ```

## Security-sensitive changes

Anything touching file upload, storage paths, authentication, or
authorization should call out its security implications explicitly in the
PR description. See `SECURITY.md` for the current threat model. Please
report vulnerabilities privately rather than via a public PR/issue — see
`SECURITY.md` for how.

## Commit messages

Use clear, imperative messages (`Add password-protected share links`, not
`fixed stuff`). Reference the related issue when one exists.

## Code of Conduct

This project follows the `CODE_OF_CONDUCT.md`. Be kind.

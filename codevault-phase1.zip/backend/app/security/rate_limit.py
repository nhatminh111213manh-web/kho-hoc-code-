"""
Minimal in-memory rate limiter.

Good enough for a single-process MVP and for Codespaces/dev. For a
multi-worker or multi-instance production deployment, swap the in-memory
`_hits` dict for Redis (the interface below — `check()` — is the only
thing that would need to change).
"""
import time
from collections import defaultdict, deque
from typing import Deque, Dict, Tuple

from fastapi import HTTPException, Request, status

_hits: Dict[Tuple[str, str], Deque[float]] = defaultdict(deque)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit(bucket: str, max_per_minute: int):
    """Returns a FastAPI dependency enforcing `max_per_minute` requests per
    client IP for the given `bucket` name (e.g. "upload", "download")."""

    def dependency(request: Request) -> None:
        ip = _client_ip(request)
        key = (bucket, ip)
        now = time.time()
        window_start = now - 60
        hits = _hits[key]
        while hits and hits[0] < window_start:
            hits.popleft()
        if len(hits) >= max_per_minute:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many requests. Please slow down and try again shortly.",
            )
        hits.append(now)

    return dependency

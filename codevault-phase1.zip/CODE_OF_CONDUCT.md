# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and maintainers pledge to make participation
in the CodeVault project a harassment-free experience for everyone,
regardless of age, body size, visible or invisible disability, ethnicity,
sex characteristics, gender identity and expression, level of experience,
education, socio-economic status, nationality, personal appearance, race,
religion, or sexual identity and orientation.

## Our Standards

Examples of behavior that contributes to a positive environment:

- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

Examples of unacceptable behavior:

- Harassment, insulting or derogatory comments, and personal attacks
- Publishing others' private information without explicit permission
- Other conduct which could reasonably be considered inappropriate in a
  professional setting

## Enforcement

Instances of unacceptable behavior may be reported to the project
maintainers. All complaints will be reviewed and investigated promptly
and fairly.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org),
version 2.1.

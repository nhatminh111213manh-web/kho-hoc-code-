"""
StorageInterface — abstraction so the API never talks to a filesystem or an
S3 bucket directly. Swapping backends (local disk, S3, R2, MinIO, B2,
Supabase Storage) means writing one new class here, nothing else in the
app changes.
"""
from abc import ABC, abstractmethod
from typing import BinaryIO, Iterator


class StorageInterface(ABC):
    @abstractmethod
    def save(self, key: str, stream: BinaryIO) -> int:
        """Persist `stream` under `key`. Returns the number of bytes written."""
        raise NotImplementedError

    @abstractmethod
    def open(self, key: str) -> Iterator[bytes]:
        """Return an iterator of byte chunks for streaming a download response."""
        raise NotImplementedError

    @abstractmethod
    def delete(self, key: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def exists(self, key: str) -> bool:
        raise NotImplementedError

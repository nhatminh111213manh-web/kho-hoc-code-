import axios from "axios";
import type { FileMetadata, UploadResponse } from "../types/file";

// In dev, Vite proxies /api to the backend (see vite.config.ts).
// In production, set VITE_API_BASE_URL to the deployed API origin.
const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "";

export const api = axios.create({ baseURL: API_BASE });

export function uploadFile(
  file: File,
  onProgress: (percent: number) => void,
  signal?: AbortSignal
): Promise<UploadResponse> {
  const formData = new FormData();
  formData.append("file", file);

  return api
    .post<UploadResponse>("/api/upload", formData, {
      signal,
      onUploadProgress: (evt) => {
        if (evt.total) onProgress(Math.round((evt.loaded / evt.total) * 100));
      },
    })
    .then((res) => res.data);
}

export function getFileMetadata(id: string): Promise<FileMetadata> {
  return api.get<FileMetadata>(`/api/files/${id}`).then((res) => res.data);
}

export function downloadUrl(id: string): string {
  return `${API_BASE}/api/files/${id}/download`;
}

"""
Application configuration.

All settings are read from environment variables (see .env.example at the
repo root). Nothing sensitive is hard-coded, and defaults are safe for local
development only — production deployments MUST override SECRET_KEY and
DATABASE_URL.
"""
from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- General ---
    APP_NAME: str = "CodeVault"
    ENV: str = "development"
    DEBUG: bool = True

    # --- Security ---
    # Used to sign session/JWT tokens. MUST be overridden in production.
    SECRET_KEY: str = "dev-secret-change-me"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # --- Database ---
    # Defaults to a local SQLite file so the project runs with zero setup.
    # docker-compose.yml overrides this with a PostgreSQL URL.
    DATABASE_URL: str = "sqlite:///./codevault.db"

    # --- CORS ---
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]

    # --- Public URLs ---
    # If set, share/download links are built from this instead of the
    # incoming request's Host header. Set this in production (behind a
    # reverse proxy / CDN) so links are stable and not dependent on
    # client-controllable headers. Example: https://codevault.example.com
    PUBLIC_BASE_URL: str = ""

    # --- Storage ---
    STORAGE_BACKEND: str = "local"  # "local" | "s3"
    LOCAL_STORAGE_PATH: str = "./uploads"

    # S3 / S3-compatible (R2, MinIO, B2) settings — only used when
    # STORAGE_BACKEND=s3. Left blank by default.
    S3_BUCKET: str = ""
    S3_REGION: str = ""
    S3_ENDPOINT_URL: str = ""
    S3_ACCESS_KEY_ID: str = ""
    S3_SECRET_ACCESS_KEY: str = ""

    # --- Upload limits & validation ---
    MAX_UPLOAD_SIZE_MB: int = 100
    # Empty blacklist/whitelist below means "not enforced". Both can be
    # configured; blacklist wins if an extension appears in both.
    ALLOWED_EXTENSIONS: List[str] = []
    BLOCKED_EXTENSIONS: List[str] = [
        "exe", "bat", "cmd", "sh", "com", "msi", "dll", "scr", "jar",
    ]

    # --- Rate limiting ---
    RATE_LIMIT_UPLOADS_PER_MINUTE: int = 10
    RATE_LIMIT_DOWNLOADS_PER_MINUTE: int = 60

    @property
    def max_upload_size_bytes(self) -> int:
        return self.MAX_UPLOAD_SIZE_MB * 1024 * 1024


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

# Ensure local storage directory exists at import time (dev convenience).
Path(settings.LOCAL_STORAGE_PATH).mkdir(parents=True, exist_ok=True)

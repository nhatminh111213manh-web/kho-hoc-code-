from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class FileMetadataOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    original_name: str
    size: int
    mime_type: str
    is_public: bool
    has_password: bool = False
    download_count: int
    expires_at: Optional[datetime] = None
    created_at: datetime


class UploadResponse(BaseModel):
    id: str
    original_name: str
    size: int
    mime_type: str
    download_url: str
    share_url: str
    created_at: datetime

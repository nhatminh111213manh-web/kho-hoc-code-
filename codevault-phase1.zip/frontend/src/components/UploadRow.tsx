import { useState } from "react";
import type { UploadItem } from "../types/file";

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let val = bytes / 1024;
  let i = 0;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${val.toFixed(1)} ${units[i]}`;
}

export function UploadRow({ item }: { item: UploadItem }) {
  const [copied, setCopied] = useState(false);

  const copyLink = async () => {
    if (!item.result) return;
    await navigator.clipboard.writeText(item.result.share_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="rounded-md border border-border bg-raised px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{item.file.name}</p>
          <p className="font-mono text-xs text-muted">{formatBytes(item.file.size)}</p>
        </div>

        {item.status === "done" && item.result && (
          <button
            onClick={copyLink}
            className="shrink-0 rounded-md bg-accent px-3 py-1.5 text-xs font-medium text-white transition-opacity hover:opacity-90"
          >
            {copied ? "Copied!" : "Copy link"}
          </button>
        )}
        {item.status === "error" && (
          <span className="shrink-0 text-xs text-danger">{item.error ?? "Upload failed"}</span>
        )}
      </div>

      {item.status === "uploading" && (
        <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-bg">
          <div
            className="h-full rounded-full bg-accent transition-[width] duration-150"
            style={{ width: `${item.progress}%` }}
          />
        </div>
      )}

      {item.status === "done" && item.result && (
        <a
          href={item.result.share_url}
          className="mt-1.5 block truncate font-mono text-xs text-accent hover:underline"
        >
          {item.result.share_url}
        </a>
      )}
    </div>
  );
}

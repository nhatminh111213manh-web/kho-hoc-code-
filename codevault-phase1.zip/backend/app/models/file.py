import secrets
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def generate_file_id() -> str:
    """
    Random, non-guessable, URL-safe identifier used in public links
    (e.g. /f/8Kx92LmP). ~8 chars of base62-ish token_urlsafe gives enough
    entropy to make enumeration infeasible while staying short.
    """
    return secrets.token_urlsafe(6).replace("_", "").replace("-", "")[:8]


class FileRecord(Base):
    __tablename__ = "files"

    # Public-facing ID used in URLs. Never expose the internal storage path.
    id: Mapped[str] = mapped_column(String(16), primary_key=True, default=generate_file_id)

    original_name: Mapped[str] = mapped_column(String(255))
    # Name used on disk / in the storage backend — never derived directly
    # from user input (see services/upload_service.py).
    stored_name: Mapped[str] = mapped_column(String(255))

    size: Mapped[int] = mapped_column(Integer)
    mime_type: Mapped[str] = mapped_column(String(127), default="application/octet-stream")

    owner_id: Mapped[Optional[str]] = mapped_column(
        String(32), ForeignKey("users.id"), nullable=True, default=None
    )
    owner = relationship("User", back_populates="files")

    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True, default=None)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, default=None)
    max_downloads: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, default=None)
    download_count: Mapped[int] = mapped_column(Integer, default=0)
    is_disabled: Mapped[bool] = mapped_column(Boolean, default=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

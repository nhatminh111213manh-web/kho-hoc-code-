"""
Upload validation: safe filenames, extension checks, size limits.

Nothing here trusts client-supplied data. `original_name` is stored purely
as display metadata (HTML-escaped on render by the frontend); it is NEVER
used to build a filesystem path. The `stored_name` used on disk is always
server-generated (see services/upload_service.py).
"""
import re
from pathlib import PurePosixPath

from fastapi import HTTPException, status

from app.config import settings

# A conservative allowlist for display purposes: strip anything that isn't
# a common filename character before showing/logging a name.
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9 ._\-()\[\]]")


def sanitize_display_name(raw_name: str) -> str:
    """Clean a user-supplied filename for safe display/storage as metadata.
    This value is never used as a filesystem path component."""
    name = PurePosixPath(raw_name or "file").name  # drop any directory parts
    name = _SAFE_NAME_RE.sub("_", name).strip()
    if not name:
        name = "file"
    return name[:255]


def get_extension(filename: str) -> str:
    if "." not in filename:
        return ""
    return filename.rsplit(".", 1)[-1].lower()


def validate_extension(filename: str) -> None:
    ext = get_extension(filename)

    if ext in {e.lower() for e in settings.BLOCKED_EXTENSIONS}:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File type '.{ext}' is not allowed.",
        )

    allowed = {e.lower() for e in settings.ALLOWED_EXTENSIONS}
    if allowed and ext not in allowed:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File type '.{ext}' is not in the allowed list.",
        )


def validate_size(size_bytes: int) -> None:
    if size_bytes <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Empty file.")
    if size_bytes > settings.max_upload_size_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB} MB limit.",
        )


class SizeLimitExceeded(Exception):
    pass


class SizeLimitedReader:
    """
    Wraps a file-like object and raises SizeLimitExceeded as soon as more
    than `limit` bytes have been read — so a storage backend streaming an
    upload to disk aborts early instead of writing an unbounded amount of
    attacker-supplied data before any size check runs.
    """

    def __init__(self, fileobj, limit: int):
        self._fileobj = fileobj
        self._limit = limit
        self._read = 0

    def read(self, size: int = -1) -> bytes:
        chunk = self._fileobj.read(size)
        self._read += len(chunk)
        if self._read > self._limit:
            raise SizeLimitExceeded()
        return chunk

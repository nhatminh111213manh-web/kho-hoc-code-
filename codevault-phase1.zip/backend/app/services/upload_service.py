import mimetypes
import uuid

from fastapi import HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.config import settings
from app.models.file import FileRecord, generate_file_id
from app.security.validation import (
    SizeLimitedReader,
    SizeLimitExceeded,
    sanitize_display_name,
    validate_extension,
    validate_size,
)
from app.storage.base import StorageInterface


def _guess_mime(filename: str, fallback: str | None) -> str:
    guessed, _ = mimetypes.guess_type(filename)
    return guessed or fallback or "application/octet-stream"


def save_upload(db: Session, storage: StorageInterface, upload: UploadFile) -> FileRecord:
    """
    Validates and persists a single uploaded file, returning its DB record.
    Works identically for anonymous and authenticated uploads — the caller
    decides whether to set owner_id.
    """
    display_name = sanitize_display_name(upload.filename or "file")
    validate_extension(display_name)

    file_id = generate_file_id()
    # stored_name is fully server-generated: an internal UUID plus the
    # original extension, never the user's raw filename. This is what
    # prevents path traversal / filename-collision / injection issues.
    ext = display_name.rsplit(".", 1)[-1] if "." in display_name else ""
    stored_name = f"{uuid.uuid4().hex}.{ext}" if ext else uuid.uuid4().hex

    limited_stream = SizeLimitedReader(upload.file, settings.max_upload_size_bytes)
    try:
        size = storage.save(stored_name, limited_stream)
    except SizeLimitExceeded:
        storage.delete(stored_name)
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB} MB limit.",
        )
    validate_size(size)

    record = FileRecord(
        id=file_id,
        original_name=display_name,
        stored_name=stored_name,
        size=size,
        mime_type=_guess_mime(display_name, upload.content_type),
        owner_id=None,
        is_public=True,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

"""
S3-compatible storage backend.

Not wired into Phase 1 (local disk is enough for the MVP), but the
interface is implemented against boto3 so switching STORAGE_BACKEND=s3
later is a config change, not a rewrite. Works against AWS S3 and any
S3-compatible service (Cloudflare R2, MinIO, Backblaze B2, Supabase
Storage) by pointing S3_ENDPOINT_URL at the provider.

Requires `boto3` (add to requirements.txt when this backend is enabled).
"""
from typing import BinaryIO, Iterator

from app.storage.base import StorageInterface


class S3Storage(StorageInterface):
    def __init__(
        self,
        bucket: str,
        region: str = "",
        endpoint_url: str = "",
        access_key_id: str = "",
        secret_access_key: str = "",
    ):
        import boto3  # imported lazily so boto3 is optional for local-only setups

        self.bucket = bucket
        self.client = boto3.client(
            "s3",
            region_name=region or None,
            endpoint_url=endpoint_url or None,
            aws_access_key_id=access_key_id or None,
            aws_secret_access_key=secret_access_key or None,
        )

    def save(self, key: str, stream: BinaryIO) -> int:
        self.client.upload_fileobj(stream, self.bucket, key)
        head = self.client.head_object(Bucket=self.bucket, Key=key)
        return head["ContentLength"]

    def open(self, key: str) -> Iterator[bytes]:
        obj = self.client.get_object(Bucket=self.bucket, Key=key)
        body = obj["Body"]
        while chunk := body.read(1024 * 1024):
            yield chunk

    def delete(self, key: str) -> None:
        self.client.delete_object(Bucket=self.bucket, Key=key)

    def exists(self, key: str) -> bool:
        from botocore.exceptions import ClientError

        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError:
            return False

import { useCallback, useState } from "react";
import { Header } from "../components/Header";
import { TerminalWindow } from "../components/TerminalWindow";
import { Dropzone } from "../components/Dropzone";
import { UploadRow } from "../components/UploadRow";
import { uploadFile } from "../services/api";
import type { UploadItem } from "../types/file";

export function HomePage() {
  const [items, setItems] = useState<UploadItem[]>([]);

  const handleFiles = useCallback((files: File[]) => {
    const newItems: UploadItem[] = files.map((file) => ({
      localId: `${file.name}-${file.size}-${Math.random().toString(36).slice(2)}`,
      file,
      progress: 0,
      status: "uploading",
    }));
    setItems((prev) => [...newItems, ...prev]);

    newItems.forEach((item) => {
      uploadFile(
        item.file,
        (progress) =>
          setItems((prev) =>
            prev.map((it) => (it.localId === item.localId ? { ...it, progress } : it))
          )
      )
        .then((result) =>
          setItems((prev) =>
            prev.map((it) =>
              it.localId === item.localId ? { ...it, status: "done", progress: 100, result } : it
            )
          )
        )
        .catch((err) =>
          setItems((prev) =>
            prev.map((it) =>
              it.localId === item.localId
                ? {
                    ...it,
                    status: "error",
                    error: err?.response?.data?.detail ?? "Upload failed. Try again.",
                  }
                : it
            )
          )
        );
    });
  }, []);

  const isUploading = items.some((i) => i.status === "uploading");

  return (
    <div className="min-h-full flex flex-col">
      <Header />

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-6 py-16 sm:py-24">
        <div className="mb-10">
          <p className="font-mono text-sm text-accent">$ codevault push ./my-project</p>
          <h1 className="mt-3 font-mono text-4xl font-semibold tracking-tight sm:text-5xl">
            Store. Share. Ship.
          </h1>
          <p className="mt-4 max-w-lg text-muted">
            Open-source cloud storage built for developers. Drop a file or a zipped project,
            get a link, send it — no account needed.
          </p>
        </div>

        <TerminalWindow title="upload.sh">
          <Dropzone onFiles={handleFiles} disabled={isUploading && false} />
        </TerminalWindow>

        {items.length > 0 && (
          <div className="mt-6 flex flex-col gap-2.5">
            {items.map((item) => (
              <UploadRow key={item.localId} item={item} />
            ))}
          </div>
        )}

        <div className="mt-16 grid grid-cols-1 gap-6 border-t border-border pt-10 sm:grid-cols-3">
          <Feature
            title="No login wall"
            body="Upload and share instantly. Create an account only if you want a dashboard, folders, and private files."
          />
          <Feature
            title="Built for code"
            body="Syntax-highlighted previews, sensible size limits, and an extension allowlist that isn't hostile to .zip and .tar.gz."
          />
          <Feature
            title="Actually open source"
            body="Self-host it, audit it, swap the storage backend for S3, R2, or MinIO. No lock-in."
          />
        </div>
      </main>

      <footer className="border-t border-border px-6 py-6 text-center font-mono text-xs text-muted">
        CodeVault is open source — MIT licensed.
      </footer>
    </div>
  );
}

function Feature({ title, body }: { title: string; body: string }) {
  return (
    <div>
      <h3 className="text-sm font-medium">{title}</h3>
      <p className="mt-1.5 text-sm text-muted">{body}</p>
    </div>
  );
}

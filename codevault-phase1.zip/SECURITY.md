# Security Policy

CodeVault accepts anonymous file uploads by design, which makes security
review especially important. Thank you for helping keep it safe.

## Reporting a vulnerability

Please **do not** open a public GitHub issue for security reports.

Instead, email the maintainers (see the repository's contact info) or use
GitHub's private vulnerability reporting (Security tab → "Report a
vulnerability"). Include:

- A description of the issue and its impact
- Steps to reproduce (a minimal example helps a lot)
- Affected version/commit

We aim to acknowledge reports within 72 hours.

## Scope of built-in protections

CodeVault's threat model assumes anonymous, potentially malicious upload
traffic. Current mitigations:

- Uploaded files are **never executed** on the server, under any
  circumstance.
- File IDs and on-disk storage names are server-generated random tokens;
  user-supplied filenames are sanitized and only ever used as display
  metadata, never as a filesystem path.
- Extension blacklist/whitelist, MIME-type detection, and a hard upload
  size cap enforced during streaming (not just after the fact).
- Per-IP rate limiting on upload and download endpoints.
- Parameterized queries via SQLAlchemy (no raw SQL string interpolation).
- Uniform 404 responses so probing can't distinguish "doesn't exist" from
  "expired" or "disabled".
- CORS is restricted to configured origins; no wildcard in production.

## Known limitations (roadmap)

- No malware/virus scanning is performed on uploaded content yet.
  Anyone deploying CodeVault publicly should consider fronting uploads
  with a scanner (e.g. ClamAV) before this lands upstream.
- CAPTCHA/anti-abuse hooks are not yet wired in (architecture supports
  adding one at the upload endpoint).
- Password-protected links and expiration are modeled in the database but
  not yet enforced end-to-end (tracked for Phase 3).

If you deploy CodeVault publicly, review `MAX_UPLOAD_SIZE_MB`,
`RATE_LIMIT_UPLOADS_PER_MINUTE`, and `BLOCKED_EXTENSIONS` in your `.env`
for your risk tolerance.

from fastapi import APIRouter, Depends, Request, UploadFile
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.schemas.file import UploadResponse
from app.security.rate_limit import rate_limit
from app.services.upload_service import save_upload
from app.storage import get_storage

router = APIRouter(prefix="/api", tags=["upload"])


@router.post(
    "/upload",
    response_model=UploadResponse,
    dependencies=[Depends(rate_limit("upload", settings.RATE_LIMIT_UPLOADS_PER_MINUTE))],
)
def upload_file(
    request: Request,
    file: UploadFile,
    db: Session = Depends(get_db),
    storage=Depends(get_storage),
):
    """
    Anonymous upload — no authentication required. Returns a unique,
    non-guessable ID and the public download/share URLs for the file.
    """
    record = save_upload(db, storage, file)

    base = settings.PUBLIC_BASE_URL.rstrip("/") or str(request.base_url).rstrip("/")
    return UploadResponse(
        id=record.id,
        original_name=record.original_name,
        size=record.size,
        mime_type=record.mime_type,
        download_url=f"{base}/api/files/{record.id}/download",
        share_url=f"{base}/f/{record.id}",
        created_at=record.created_at,
    )

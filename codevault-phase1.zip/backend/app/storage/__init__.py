from functools import lru_cache

from app.config import settings
from app.storage.base import StorageInterface
from app.storage.local import LocalStorage


@lru_cache
def get_storage() -> StorageInterface:
    if settings.STORAGE_BACKEND == "s3":
        from app.storage.s3 import S3Storage

        return S3Storage(
            bucket=settings.S3_BUCKET,
            region=settings.S3_REGION,
            endpoint_url=settings.S3_ENDPOINT_URL,
            access_key_id=settings.S3_ACCESS_KEY_ID,
            secret_access_key=settings.S3_SECRET_ACCESS_KEY,
        )
    return LocalStorage(settings.LOCAL_STORAGE_PATH)

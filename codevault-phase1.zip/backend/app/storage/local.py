import os
import shutil
from pathlib import Path
from typing import BinaryIO, Iterator

from app.storage.base import StorageInterface

CHUNK_SIZE = 1024 * 1024  # 1 MB


class LocalStorage(StorageInterface):
    """
    Stores files on local disk under `base_path`. Keys are always the
    server-generated `stored_name` (never a raw user-supplied filename), so
    there is no path-traversal surface here — but we still normalize and
    verify every resolved path stays inside `base_path` as defense in depth.
    """

    def __init__(self, base_path: str):
        self.base_path = Path(base_path).resolve()
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _resolve(self, key: str) -> Path:
        # Reject any key that isn't a plain filename (no separators, no ..).
        if "/" in key or "\\" in key or key in ("", ".", ".."):
            raise ValueError("Invalid storage key")
        path = (self.base_path / key).resolve()
        if self.base_path not in path.parents and path != self.base_path:
            raise ValueError("Resolved path escapes storage root")
        return path

    def save(self, key: str, stream: BinaryIO) -> int:
        dest = self._resolve(key)
        total = 0
        with open(dest, "wb") as out:
            while chunk := stream.read(CHUNK_SIZE):
                out.write(chunk)
                total += len(chunk)
        return total

    def open(self, key: str) -> Iterator[bytes]:
        path = self._resolve(key)
        with open(path, "rb") as f:
            while chunk := f.read(CHUNK_SIZE):
                yield chunk

    def delete(self, key: str) -> None:
        path = self._resolve(key)
        if path.exists():
            os.remove(path)

    def exists(self, key: str) -> bool:
        try:
            return self._resolve(key).exists()
        except ValueError:
            return False

import type { ReactNode } from "react";

interface TerminalWindowProps {
  title: string;
  children: ReactNode;
  className?: string;
}

/**
 * A window-chrome frame (traffic-light dots + title bar) used to hold the
 * upload zone and file-view card. It's the one recurring visual motif that
 * ties the product's "developer tool" identity together, so we lean on it
 * instead of generic rounded cards with drop shadows.
 */
export function TerminalWindow({ title, children, className = "" }: TerminalWindowProps) {
  return (
    <div className={`rounded-lg border border-border bg-surface overflow-hidden ${className}`}>
      <div className="flex items-center gap-2 border-b border-border bg-raised px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-[#F0665C]/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#F5C242]/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#3FD186]/70" />
        <span className="ml-2 font-mono text-xs text-muted">{title}</span>
      </div>
      <div className="p-6 sm:p-8">{children}</div>
    </div>
  );
}

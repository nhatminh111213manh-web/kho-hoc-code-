import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Header } from "../components/Header";
import { TerminalWindow } from "../components/TerminalWindow";
import { getFileMetadata, downloadUrl } from "../services/api";
import type { FileMetadata } from "../types/file";

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let val = bytes / 1024;
  let i = 0;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${val.toFixed(1)} ${units[i]}`;
}

function extOf(name: string): string {
  return name.includes(".") ? name.split(".").pop()!.toUpperCase() : "FILE";
}

export function FileViewPage() {
  const { id } = useParams<{ id: string }>();
  const [meta, setMeta] = useState<FileMetadata | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    getFileMetadata(id)
      .then(setMeta)
      .catch((err) => {
        if (err?.response?.status === 404) setError("This file doesn't exist or has expired.");
        else if (err?.response?.status === 403) setError("This file is private.");
        else setError("Something went wrong loading this file.");
      });
  }, [id]);

  return (
    <div className="min-h-full flex flex-col">
      <Header />
      <main className="mx-auto flex w-full max-w-xl flex-1 flex-col justify-center px-6 py-16">
        <TerminalWindow title={id ? `f/${id}` : "file"}>
          {error && (
            <div className="text-center">
              <p className="text-danger">{error}</p>
              <Link to="/" className="mt-4 inline-block text-sm text-accent hover:underline">
                ← Upload a file instead
              </Link>
            </div>
          )}

          {!error && !meta && <p className="text-center text-muted">Loading…</p>}

          {meta && (
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-md bg-accent-soft font-mono text-xs font-semibold text-accent">
                {extOf(meta.original_name)}
              </div>
              <h1 className="break-all text-lg font-medium">{meta.original_name}</h1>
              <dl className="mt-3 flex gap-4 font-mono text-xs text-muted">
                <div>
                  <dt className="inline">Size: </dt>
                  <dd className="inline text-text">{formatBytes(meta.size)}</dd>
                </div>
                <div>
                  <dt className="inline">Downloads: </dt>
                  <dd className="inline text-text">{meta.download_count}</dd>
                </div>
              </dl>
              <a
                href={downloadUrl(meta.id)}
                className="mt-7 w-full rounded-md bg-accent px-4 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90"
              >
                Download
              </a>
              <p className="mt-4 font-mono text-[11px] text-muted">No account required</p>
            </div>
          )}
        </TerminalWindow>
      </main>
    </div>
  );
}

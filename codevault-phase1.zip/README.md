# CodeVault

**Open-source cloud storage and instant file sharing for developers.**

Drop a file or a zipped project, get a link, share it. No account required
to upload or download a public file. Create an account only if you want a
dashboard, folders, and private files.

> **Status:** Phase 1 (MVP) complete — anonymous upload, unique download
> links, anonymous download. See [Roadmap](#roadmap) for what's next.

> 📸 *Screenshots coming soon — add `docs/screenshot-home.png` and
> `docs/screenshot-file.png` and link them here.*

## Features (Phase 1)

- 🚀 Drag-and-drop or click-to-browse upload — single or multiple files
- 🔓 No login required to upload or download a public file
- 🔗 Unique, non-guessable share link per file (`/f/<id>`)
- 📊 Live upload progress
- 🛡️ Server-side validation: size limits, extension allow/blacklist,
  path-traversal-safe storage, rate limiting — uploaded files are **never
  executed** on the server
- 🧩 Pluggable storage backend (local disk today; S3/R2/MinIO/B2-ready)
- 🐳 One-command local setup via Docker Compose, and ready for GitHub
  Codespaces out of the box

See [`SECURITY.md`](SECURITY.md) for the full threat model and mitigations.

## Tech stack

| Layer    | Choice                                                   |
| -------- | --------------------------------------------------------- |
| Backend  | Python, FastAPI, SQLAlchemy, Pydantic, PostgreSQL (SQLite in local/no-Docker dev) |
| Frontend | React, TypeScript, Vite, Tailwind CSS                    |
| Storage  | Local disk (MVP) behind a `StorageInterface` abstraction; S3-compatible backend stubbed for later |
| Infra    | Docker, Docker Compose, GitHub Codespaces devcontainer   |

## Project structure

```text
codevault/
├── backend/
│   ├── app/
│   │   ├── main.py           # FastAPI app, CORS, error handling
│   │   ├── config.py         # env-driven settings
│   │   ├── database.py       # SQLAlchemy engine/session
│   │   ├── models/           # FileRecord, User (ORM)
│   │   ├── schemas/          # Pydantic response models
│   │   ├── routers/          # /api/upload, /api/files/*
│   │   ├── services/         # upload orchestration
│   │   ├── storage/          # StorageInterface, LocalStorage, S3Storage
│   │   └── security/         # filename/size validation, rate limiting
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/       # Header, Dropzone, TerminalWindow, UploadRow
│   │   ├── pages/            # HomePage, FileViewPage
│   │   ├── services/         # api.ts (axios client)
│   │   └── types/
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
├── .devcontainer/
├── .env.example
└── README.md (you are here)
```

## Development setup

### Option A — GitHub Codespaces (fastest)

1. Click **Code → Create codespace on main** on the GitHub repo.
2. Wait for the container to build (installs backend + frontend deps
   automatically via `postCreateCommand`).
3. Once it's up, run (see [Running it](#running-it) below).
4. Codespaces will prompt to forward ports `8000` (API) and `5173`
   (frontend) — open the `5173` preview.

### Option B — Docker Compose (local machine)

Requires Docker + Docker Compose.

```bash
git clone https://github.com/<your-org>/codevault.git
cd codevault
cp .env.example .env        # adjust values if you want
docker compose up --build
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- Interactive API docs (Swagger UI): http://localhost:8000/docs
- PostgreSQL: localhost:5432 (user/pass/db: `codevault`)

Stop with `Ctrl+C`, or `docker compose down` to also remove containers
(add `-v` to also wipe the Postgres/uploads volumes).

### Option C — Run without Docker

Backend (uses local SQLite by default — no Postgres needed):

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Frontend, in a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173.

## Environment variables

See [`.env.example`](.env.example) (root, used by Docker Compose) and
[`frontend/.env.example`](frontend/.env.example) for the full list. Key ones:

| Variable | Default | Purpose |
| --- | --- | --- |
| `SECRET_KEY` | `dev-secret-change-me` | **Change in production.** Used for future auth token signing. |
| `DATABASE_URL` | `sqlite:///./codevault.db` | Set to a Postgres URL in production (Docker Compose does this for you). |
| `MAX_UPLOAD_SIZE_MB` | `100` | Hard per-file upload cap, enforced during streaming. |
| `BLOCKED_EXTENSIONS` | `exe,bat,cmd,sh,com,msi,dll,scr,jar` | Extensions rejected outright. |
| `ALLOWED_EXTENSIONS` | *(empty = not enforced)* | If set, only these extensions are accepted. |
| `RATE_LIMIT_UPLOADS_PER_MINUTE` | `10` | Per-IP upload rate limit. |
| `STORAGE_BACKEND` | `local` | `local` or `s3` (see `app/storage/`). |
| `PUBLIC_BASE_URL` | *(empty)* | Set in production so share links use your real domain rather than the request's Host header. |
| `VITE_API_BASE_URL` | *(empty)* | Frontend: API origin in production. Empty in dev (Vite proxies `/api`). |

Never commit a real `.env` — it's already in `.gitignore`.

## API reference (Phase 1)

Full interactive docs are auto-generated at `/docs` once the backend is
running. Summary:

| Method | Path | Auth | Description |
| --- | --- | --- | --- |
| `POST` | `/api/upload` | none | Upload a file (`multipart/form-data`, field name `file`). Returns the file ID, download URL, and share URL. |
| `GET` | `/api/files/{id}` | none (public files) | File metadata: name, size, MIME type, download count. |
| `GET` | `/api/files/{id}/download` | none (public files) | Streams the file with a `Content-Disposition: attachment` header. |
| `GET` | `/api/health` | none | Liveness check. |

Example:

```bash
curl -F "file=@my-project.zip" http://localhost:8000/api/upload
# → {"id":"8Kx92LmP","share_url":"http://localhost:8000/f/8Kx92LmP", ...}

curl -O -J http://localhost:8000/api/files/8Kx92LmP/download
```

## Roadmap

- **Phase 1 — done:** homepage, anonymous upload/download, unique links,
  upload progress, file metadata.
- **Phase 2:** registration/login, dashboard, folders, file management,
  search.
- **Phase 3:** in-browser code preview (Monaco Editor), link sharing UI,
  expiration, password-protected links.
- **Phase 4:** GitHub integration, file version history, AI coding
  assistant, team collaboration, additional cloud storage providers.

The storage layer, database schema, and API are already shaped with these
phases in mind (e.g. `owner_id`, `expires_at`, `password_hash`,
`max_downloads` already exist on `FileRecord`; they're just not enforced
by the UI yet).

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md) and [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md).
Please report security issues privately — see [`SECURITY.md`](SECURITY.md).

## License

[MIT](LICENSE)
